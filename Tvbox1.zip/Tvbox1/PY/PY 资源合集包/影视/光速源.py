# -*- coding: utf-8 -*-
"""
光速影视聚合爬虫（内置去广告清洗）
- 支持分类列表爬取与分类筛选
- 播放 M3U8 时通过本地代理清洗广告
"""

import sys
import concurrent.futures
import re
import requests
import time
from urllib.parse import urljoin, urlparse, quote, parse_qs, urlencode, urlunparse
from collections import OrderedDict

sys.path.append("..")
from base.spider import Spider


class Spider(Spider):
    API_URL = "https://api.guangsuapi.com/api.php/provide/vod/josn"

    # ==================== 内容过滤 ====================
    # 分类名命中这些关键词时，不在首页分类、分类列表和搜索结果中展示。
    BLOCKED_CATEGORY_KEYWORDS = (
        "伦理",
        "福利",
        "伦理片",
        "倫理片",
        "港台三级",
        "里番动漫",
        "里番",
        "韩国伦理",
        "两性课堂",
        "写真热舞",
        "擦边剧",
        "擦边短剧",
        "西方伦理",
        "日本伦理",
    )

    # ==================== M3U8 广告清洗 ====================
    # 精确路径规则。
    AD_PATH_KEYWORDS = (
        "/adjump/",
        "/ad/",
        "/ads/",
        "/advert/",
        "/advertise/",
        "/advertisement/",
        "/commercial/",
        "/promotion/",
        "/promote/",
        "/banner/",
        "/pre-roll/",
        "/preroll/",
        "/mid-roll/",
        "/midroll/",
        "/post-roll/",
        "/postroll/",
    )

    # URL / 文件名 / 查询参数中的常见广告特征。
    AD_URL_KEYWORDS = (
        "ad.mp4",
        "ad.ts",
        "ad.m3u8",
        "ads.ts",
        "ads.m3u8",
        "advert.ts",
        "advert.m3u8",
        "advertising",
        "advertisement",
        "adbreak",
        "ad_break",
        "adbreaks",
        "adserver",
        "adserver.",
        "adsystem",
        "doubleclick",
        "googlesyndication",
        "googleadservices",
        "adservice",
        "adsafeprotected",
        "adform",
        "amazon-adsystem",
        "criteo",
        "tracking",
        "tracker",
        "promotion",
        "promote",
        "commercial",
    )

    # M3U8 标记中明确表示广告/插播的关键词。
    AD_TAG_KEYWORDS = (
        "SCTE35",
        "SCTE-35",
        "CUE-OUT",
        "CUE-OUT-CONT",
        "CUE-IN",
        "DATERANGE",
        "CLASS=\"AD",
        "CLASS=\"AD-",
        "CLASS=\"SCTE",
    )

    # 常见广告 EXT-X 标记；用于删除相关广告段。
    AD_EXT_TAGS = (
        "#EXT-X-CUE-OUT",
        "#EXT-X-CUE-IN",
        "#EXT-X-SPLICE-INSERT",
    )

    TIMEOUT = 12
    MAX_RETRIES = 2
    MAX_CACHE_SIZE = 50

    def init(self, extend=""):
        self.session = requests.Session()
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/131.0.0.0 Safari/537.36"
            )
        }
        # 使用 OrderedDict 实现简易 LRU 缓存
        self.cache = OrderedDict()

    # ==================== 缓存管理 ====================
    def _get_cache(self, url):
        if url in self.cache:
            self.cache.move_to_end(url)
            return self.cache[url]
        return None

    def _set_cache(self, url, content):
        self.cache[url] = content
        self.cache.move_to_end(url)
        if len(self.cache) > self.MAX_CACHE_SIZE:
            self.cache.popitem(last=False)

    # ==================== M3U8 清洗 ====================
    def _fetch_m3u8(self, url):
        """抓取 M3U8，失败后自动重试。"""
        for attempt in range(1, self.MAX_RETRIES + 1):
            try:
                resp = self.session.get(url, headers=self.headers, timeout=self.TIMEOUT)
                if resp.status_code == 200 and resp.text:
                    return resp.text
            except Exception:
                if attempt < self.MAX_RETRIES:
                    time.sleep(0.5)
        return None

    def _parse_segments(self, lines):
        """按媒体段边界划分 M3U8 片段，同时保留广告标记所在片段。"""
        segments = []
        current = []

        for line in lines:
            line = line.strip()
            if not line:
                continue

            current.append(line)

            # 一个 EXTINF + URL 构成一个媒体段；
            # DISCONTINUITY 作为独立边界也要保留在当前片段。
            if line.startswith("#EXTINF:"):
                continue

            if current and not line.startswith("#"):
                segments.append(current)
                current = []

            elif line == "#EXT-X-DISCONTINUITY":
                if current:
                    segments.append(current)
                    current = []

        if current:
            segments.append(current)

        return segments

    def _is_ad_url(self, url):
        """判断 TS/资源 URL 是否具有明显广告特征。"""
        if not url:
            return False

        value = url.strip().lower()
        parsed = urlparse(value)

        # 路径优先判断，避免把普通查询参数误判。
        path = parsed.path.lower()
        full = value

        if any(keyword in path for keyword in self.AD_PATH_KEYWORDS):
            return True

        if any(keyword.lower() in full for keyword in self.AD_URL_KEYWORDS):
            return True

        # 常见广告参数。
        query = parsed.query.lower()
        ad_params = (
            "ad=", "ads=", "adid=", "adid=", "advert=", "advertising=",
            "campaign=", "creative=", "placement=", "sponsor="
        )
        return any(param in query for param in ad_params)

    def _line_has_ad_tag(self, line):
        """判断 M3U8 标签是否明确带有广告/插播标记。"""
        upper = line.upper()
        if any(tag in upper for tag in self.AD_EXT_TAGS):
            return True
        return any(keyword.upper() in upper for keyword in self.AD_TAG_KEYWORDS)

    def _segment_has_ad(self, segment):
        """综合 URL、标签和 EXT-X 标记判断一个媒体片段是否为广告。"""
        for line in segment:
            stripped = line.strip()
            if self._line_has_ad_tag(stripped):
                return True

            if not stripped.startswith("#") and self._is_ad_url(stripped):
                return True

        return False

    def _rewrite_urls_in_segment(self, segment, base_url):
        """把片段中的相对 URL 转换为绝对 URL。"""
        new_segment = []
        i = 0
        while i < len(segment):
            line = segment[i]
            # 处理加密 KEY
            if line.startswith("#EXT-X-KEY:") and "URI=" in line:
                match = re.search(r'URI="([^"]+)"', line)
                if match:
                    old_uri = match.group(1)
                    if not old_uri.startswith(("http://", "https://")):
                        new_uri = urljoin(base_url, old_uri)
                        line = line.replace(f'URI="{old_uri}"', f'URI="{new_uri}"')
                new_segment.append(line)
                i += 1
                continue
            # EXTINF 后面通常紧跟 TS 地址
            if line.startswith("#EXTINF:"):
                new_segment.append(line)
                if i + 1 < len(segment):
                    ts_path = segment[i + 1].strip()
                    if not ts_path.startswith(("http://", "https://")):
                        ts_path = urljoin(base_url, ts_path)
                    new_segment.append(ts_path)
                    i += 2
                continue
            new_segment.append(line)
            i += 1
        return new_segment

    def _clean_m3u8_content(self, content, base_url, debug=False):
        """
        M3U8 广告清洗：
        1. 过滤广告 URL/文件名；
        2. 过滤 CUE-OUT/CUE-IN/SCTE35/DATERANGE 等广告标记段；
        3. 删除 /adjump/ 等广告路径；
        4. 保留正常 EXT-X-KEY；
        5. 自动把相对 TS/KEY URL 转成绝对 URL。
        """
        lines = content.splitlines()
        result = []
        ad_count = 0
        in_ad_break = False

        i = 0
        while i < len(lines):
            raw = lines[i].strip()
            i += 1

            if not raw:
                continue

            # 明确的广告开始/结束标记。
            upper = raw.upper()

            if upper.startswith("#EXT-X-CUE-OUT") or "CUE-OUT" in upper:
                in_ad_break = True
                ad_count += 1
                continue

            if upper.startswith("#EXT-X-CUE-IN") or "CUE-IN" in upper:
                in_ad_break = False
                continue

            # 广告 DATERANGE / SCTE35 等标签直接过滤。
            if self._line_has_ad_tag(raw):
                ad_count += 1
                continue

            # 如果当前处于 CUE-OUT 广告区，跳过直到 CUE-IN。
            if in_ad_break:
                if raw.startswith("#EXTINF:"):
                    # 同时跳过其后的媒体 URL。
                    if i < len(lines) and not lines[i].strip().startswith("#"):
                        i += 1
                    ad_count += 1
                continue

            # ENDLIST 正常保留。
            if upper == "#EXT-X-ENDLIST":
                result.append(raw)
                continue

            # KEY URI 相对地址转换。
            if raw.startswith("#EXT-X-KEY:") and "URI=" in raw:
                match = re.search(r'URI="([^"]+)"', raw, re.I)
                if match:
                    old_uri = match.group(1)
                    if not old_uri.startswith(("http://", "https://")):
                        new_uri = urljoin(base_url, old_uri)
                        raw = raw.replace(
                            f'URI="{old_uri}"',
                            f'URI="{new_uri}"'
                        )
                result.append(raw)
                continue

            # EXT-X-MAP 中的初始化片段也检查广告 URL。
            if raw.startswith("#EXT-X-MAP:") and "URI=" in raw:
                match = re.search(r'URI="([^"]+)"', raw, re.I)
                if match and self._is_ad_url(match.group(1)):
                    ad_count += 1
                    continue

                if match:
                    old_uri = match.group(1)
                    if not old_uri.startswith(("http://", "https://")):
                        new_uri = urljoin(base_url, old_uri)
                        raw = raw.replace(
                            f'URI="{old_uri}"',
                            f'URI="{new_uri}"'
                        )
                result.append(raw)
                continue

            # EXTINF 后面的媒体 URL。
            if raw.startswith("#EXTINF:"):
                if i < len(lines):
                    media_url = lines[i].strip()

                    if self._is_ad_url(media_url):
                        ad_count += 1
                        i += 1
                        continue

                    if not media_url.startswith(("http://", "https://")):
                        media_url = urljoin(base_url, media_url)

                    result.append(raw)
                    result.append(media_url)
                    i += 1
                    continue

                result.append(raw)
                continue

            # 普通媒体 URL 也检查。
            if not raw.startswith("#") and self._is_ad_url(raw):
                ad_count += 1
                continue

            # 其他正常 M3U8 标签。
            result.append(raw)

        if debug:
            result.insert(
                0,
                f"# 红牛/360 M3U8广告清洗：过滤 {ad_count} 个广告标记/媒体段"
            )

        return "\n".join(result)

    def _pick_variant(self, content, base_url):
        """从多码率 M3U8 中选择最高 BANDWIDTH 的播放列表。"""
        lines = [line.strip() for line in content.splitlines() if line.strip()]
        best_url, best_bandwidth = None, -1
        for i, line in enumerate(lines):
            if line.startswith("#EXT-X-STREAM-INF"):
                match = re.search(r"BANDWIDTH=(\d+)", line)
                bandwidth = int(match.group(1)) if match else 0
                for j in range(i + 1, len(lines)):
                    if not lines[j].startswith("#"):
                        variant_url = urljoin(base_url, lines[j])
                        if bandwidth >= best_bandwidth:
                            best_url = variant_url
                            best_bandwidth = bandwidth
                        break
        return best_url

    # ==================== URL 处理与网络接口 ====================
    def _normalize_url(self, url):
        """删除常见随机/时间戳参数，提高缓存命中率。"""
        parsed = urlparse(url)
        query_params = parse_qs(parsed.query)
        for param in ("_", "t", "timestamp", "rand", "v", "cb", "callback"):
            query_params.pop(param, None)
        return urlunparse(parsed._replace(query=urlencode(query_params, doseq=True)))

    def build_url(self, base, query):
        if "?" in base:
            return base if base.endswith(("?", "&")) else base + "&" + query
        return base + "?" + query

    def fetch_json(self, url, timeout=10):
        try:
            resp = self.session.get(url, headers=self.headers, timeout=timeout)
            if resp.status_code == 200:
                return resp.json()
        except Exception:
            pass
        return None

    # ==================== 内容过滤辅助函数 ====================

    def _is_blocked_category(self, category_name):
        """判断分类是否属于需要过滤的分类。"""
        name = str(category_name or "").strip().lower()
        if not name:
            return False
        return any(keyword.lower() in name for keyword in self.BLOCKED_CATEGORY_KEYWORDS)

    def _is_blocked_item(self, item):
        """判断视频是否属于需要过滤的分类。"""
        if not item:
            return False

        # 常见 XML/JSON 字段兼容。
        category = (
            item.get("type_name")
            or item.get("vod_class")
            or item.get("vod_type")
            or item.get("type")
            or ""
        )
        if self._is_blocked_category(category):
            return True

        # 部分资源站可能把分类信息放在备注/标签字段中。
        extra_fields = (
            item.get("vod_tag"),
            item.get("vod_remarks"),
            item.get("vod_content"),
        )
        for value in extra_fields:
            if self._is_blocked_category(value):
                return True

        return False

    def _filter_video_list(self, items):
        """过滤违规分类视频，并去除重复 vod_id。"""
        result = []
        seen = set()

        for item in items or []:
            if self._is_blocked_item(item):
                continue

            vod_id = str(item.get("vod_id", "")).strip()
            key = vod_id or repr(sorted(item.items()))

            if key in seen:
                continue

            seen.add(key)
            result.append(item)

        return result

    # ==================== 视频数据接口 ====================
    def clean_item(self, item):
        item.pop("vod_down_from", None)
        item.pop("vod_down_url", None)
        return item

    def homeContent(self, filter=False):
        """爬取首页分类，并过滤指定分类。"""
        classes = []
        url = self.build_url(self.API_URL, "ac=list")
        data = self.fetch_json(url, timeout=5)

        if data and "class" in data:
            seen = set()

            for category in data.get("class", []):
                type_id = str(category.get("type_id", "")).strip()
                type_name = str(category.get("type_name", "")).strip()

                if not type_id or not type_name:
                    continue

                if self._is_blocked_category(type_name):
                    continue

                if type_id in seen:
                    continue

                seen.add(type_id)
                classes.append({
                    "type_id": type_id,
                    "type_name": type_name,
                })

        return {"class": classes, "filters": {}, "list": []}

    def homeVideoContent(self):
        """主页推荐视频：获取最新视频后执行分类过滤。"""
        url = self.build_url(self.API_URL, "ac=detail&pg=1")
        data = self.fetch_json(url, timeout=10)

        if not data or "list" not in data:
            return {"list": []}

        items = self._filter_video_list(data.get("list", []))
        video_list = [self.clean_item(item) for item in items]
        return {"list": video_list}

    def categoryContent(self, tid, pg=1, filter=False, extend=None):
        """按分类获取视频列表，并过滤指定分类。"""
        # 兼容空分类。
        tid = str(tid or "").strip()
        if not tid:
            return {
                "list": [],
                "page": pg,
                "pagecount": 0,
                "limit": 20,
                "total": 0,
            }

        query = f"ac=detail&t={quote(tid)}&pg={pg}"
        url = self.build_url(self.API_URL, query)
        data = self.fetch_json(url, timeout=10)

        if not data:
            return {
                "list": [],
                "page": pg,
                "pagecount": 0,
                "limit": 20,
                "total": 0,
            }

        items = self._filter_video_list(data.get("list", []))
        video_list = [self.clean_item(item) for item in items]

        return {
            "list": video_list,
            "page": int(data.get("page", pg)),
            "pagecount": int(data.get("pagecount", 0)),
            "limit": int(data.get("limit", 20)),
            "total": len(video_list),
        }

    def detailContent(self, ids):
        if not ids:
            return {"list": []}

        real_id = ids[0]
        url = self.build_url(
            self.API_URL,
            f"ac=detail&ids={quote(str(real_id))}"
        )
        data = self.fetch_json(url, timeout=10)

        if not data or "list" not in data:
            return {"list": []}

        items = self._filter_video_list(data.get("list", []))
        result_list = [self.clean_item(item) for item in items]
        return {"list": result_list}

    def searchContent(self, key, quick=False, pg=1):
        """搜索并过滤指定分类。"""
        keyword = str(key or "").strip()

        if not keyword:
            return {
                "list": [],
                "page": pg,
                "pagecount": 0,
                "limit": 40,
                "total": 0,
            }

        encoded_keyword = quote(keyword)
        url = self.build_url(
            self.API_URL,
            f"ac=detail&wd={encoded_keyword}&pg={pg}"
        )
        data = self.fetch_json(url, timeout=8)

        if not data or "list" not in data:
            return {
                "list": [],
                "page": pg,
                "pagecount": 0,
                "limit": 40,
                "total": 0,
            }

        items = self._filter_video_list(data.get("list", []))
        video_list = [self.clean_item(item) for item in items]

        return {
            "list": video_list,
            "page": int(data.get("page", pg)),
            "pagecount": int(data.get("pagecount", 0)),
            "limit": int(data.get("limit", 40)),
            "total": len(video_list),
        }

    # ==================== 播放与代理 ====================
    def playerContent(self, flag, id, vipFlags=None):
        raw_url = id
        if not raw_url:
            return {"parse": 0, "url": ""}

        if ".m3u8" in raw_url.lower():
            try:
                base_proxy = self.getProxyUrl(local=True)
            except TypeError:
                base_proxy = self.getProxyUrl()
            proxy_url = base_proxy + "&action=clean&src=" + quote(raw_url, safe="")
            return {"parse": 0, "url": proxy_url}

        return {"parse": 0, "url": raw_url}

    def localProxy(self, param):
        if param.get("action") != "clean":
            return []

        src_url = param.get("src")
        if not src_url:
            return [400, "text/plain; charset=utf-8", "缺少 src 参数"]

        norm_url = self._normalize_url(src_url)

        # 命中 LRU 缓存
        cached_content = self._get_cache(norm_url)
        if cached_content is not None:
            return [
                200,
                "application/vnd.apple.mpegurl",
                cached_content,
                {
                    "Access-Control-Allow-Origin": "*",
                    "Cache-Control": "no-cache, no-store",
                },
            ]

        try:
            content = self._fetch_m3u8(src_url)
            if not content:
                return [500, "text/plain; charset=utf-8", "获取 m3u8 失败"]

            base_url = src_url.rsplit("/", 1)[0] + "/"
            hops = 0
            # 跟随多码率，最高 3 层
            while "#EXT-X-STREAM-INF" in content and hops < 3:
                variant = self._pick_variant(content, base_url)
                if not variant:
                    break
                sub_content = self._fetch_m3u8(variant)
                if not sub_content:
                    break
                content = sub_content
                base_url = variant.rsplit("/", 1)[0] + "/"
                hops += 1

            cleaned = self._clean_m3u8_content(content, base_url, debug=False)

            # 写入 LRU 缓存
            self._set_cache(norm_url, cleaned)

            return [
                200,
                "application/vnd.apple.mpegurl",
                cleaned,
                {
                    "Access-Control-Allow-Origin": "*",
                    "Cache-Control": "no-cache, no-store",
                },
            ]
        except Exception as e:
            return [500, "text/plain; charset=utf-8", f"清洗失败: {e}"]

    def isVideoFormat(self, url):
        return False

    def manualVideoCheck(self):
        pass

    def destroy(self):
        try:
            self.session.close()
        except Exception:
            pass