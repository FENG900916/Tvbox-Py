# coding=utf-8
# 可可影視 TVBox / 影視 (Pyramid) Python 爬蟲 —— 年份動態更新版
import re
import sys
import datetime
from urllib.parse import quote
import requests

sys.path.append('..')
from base.spider import Spider

try:
    from lxml import etree
except Exception:  # 極少數環境沒有 lxml，改用正則後備
    etree = None

try:
    requests.packages.urllib3.disable_warnings()
except Exception:
    pass

class Spider(Spider):
    SITE = "https://103.51.147.112:51120"
    IMG_CDN = "https://vres.esadj.com"
    UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
          "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
    SITE_TITLE = "可可影视-kekys.com"
    SKIP_LINES = ("4K",)

    def getName(self):
        return "可可影視"

    def init(self, extend=""):
        self.pattern_cache = {}
        self.page1_ids = {}
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": self.UA,
            "Referer": self.SITE + "/",
        })

    def isVideoFormat(self, url):
        return False

    def manualVideoCheck(self):
        return False

    def destroy(self):
        pass

    @staticmethod
    def _f(names):
        return [{"n": "全部", "v": ""}] + [{"n": n, "v": n} for n in names]

    # ------------------------------------------------------------------
    # 建立多維度篩選器 (類型、地區、語言、年份、排序)
    # ------------------------------------------------------------------
    def _build_filters(self):
        f = self._f
        
        # 共用選項
        areas = f("大陆 香港 台湾 美国 韩国 日本 泰国 英国 印度 法国 德国 其他".split())
        langs = f("国语 英语 粤语 闽南语 韩语 日语 泰语 法语 德语 其他".split())
        
        # 動態取得當前年份，確保每年自動更新 (例如到 2026 年就會變成 2026 ~ 2001)
        current_year = datetime.datetime.now().year
        years = f([str(y) for y in range(current_year, 2000, -1)])
        
        # 排序對應常見 MacCMS 參數
        sorts = [
            {"n": "預設", "v": ""},
            {"n": "最新", "v": "time"},
            {"n": "最熱 (人氣)", "v": "hits"},
            {"n": "好評 (評分)", "v": "score"},
        ]
        
        # 各分類的專屬類型
        classes = {
            "1": f("剧情 喜剧 动作 爱情 恐怖 惊悚 犯罪 科幻 悬疑 奇幻 冒险 战争 历史 古装 家庭 传记 武侠 歌舞 短片 动画 儿童 职场".split()),
            "2": f("剧情 爱情 喜剧 犯罪 悬疑 古装 动作 家庭 惊悚 奇幻 美剧 科幻 历史 战争 韩剧 武侠 言情 恐怖 冒险 都市 职场".split()),
            "3": f("动态漫画 剧情 动画 喜剧 冒险 动作 奇幻 科幻 儿童 搞笑 爱情 家庭 短片 热血 益智 悬疑 经典 校园 Anime 运动 亲子 青春 恋爱 武侠 惊悚".split()),
            "4": f("纪录 真人秀 记录 脱口秀 剧情 历史 喜剧 传记 相声 节目 歌舞 冒险 运动 Season 犯罪 短片 搞笑 晚会".split()),
            "6": f("王爷太子 霸道总裁 屌丝逆袭 赘婿系列 重生系列 穿越 短剧 美女总裁 娇妻系列 龙王系列 都市言情 逆袭 甜宠 虐恋 重生 剧情 科幻 武侠 爱情 动作 战争 冒险 其它".split()),
        }
        
        filters = {}
        for tid, cls_list in classes.items():
            filters[tid] = [
                {"key": "class", "name": "類型", "value": cls_list},
                {"key": "area", "name": "地區", "value": areas},
                {"key": "lang", "name": "語言", "value": langs},
                {"key": "year", "name": "年份", "value": years},
                {"key": "by", "name": "排序", "value": sorts},
            ]
        return filters

    def homeContent(self, filter):
        classes = [
            {"type_id": "1", "type_name": "電影"},
            {"type_id": "2", "type_name": "連續劇"},
            {"type_id": "3", "type_name": "動漫"},
            {"type_id": "4", "type_name": "綜藝紀錄"},
            {"type_id": "6", "type_name": "短劇"},
        ]
        return {"class": classes, "filters": self._build_filters()}

    def homeVideoContent(self):
        for path in ("/", "/channel/1.html"):
            try:
                lst = self._parse_list(self._fetch(self.SITE + path))
            except Exception:
                continue
            if lst:
                return {"list": lst[:24]}
        return {"list": []}

    # ------------------------------------------------------------------
    # 分類列表（動態注入多維度篩選）
    # ------------------------------------------------------------------
    def categoryContent(self, tid, pg, filter, extend):
        pg = int(pg or 1)
        
        # 取得所有篩選條件
        cls = extend.get("class", "") if isinstance(extend, dict) else ""
        area = extend.get("area", "") if isinstance(extend, dict) else ""
        lang = extend.get("lang", "") if isinstance(extend, dict) else ""
        year = extend.get("year", "") if isinstance(extend, dict) else ""
        by = extend.get("by", "") if isinstance(extend, dict) else ""
        
        # 網址中的預設排序參數
        if not by:
            by = "3"
            
        c = quote(cls)
        a = quote(area)
        l = quote(lang)
        y = quote(year)
        
        mode = f"ch:{tid}:{c}_{a}_{l}_{y}_{by}"

        # 支援多重條件的 URL 格式
        candidates = [
            lambda p: f"{self.SITE}/show/{tid}-{c}-{a}-{l}-{y}-{by}-{p}.html",
            lambda p: f"{self.SITE}/show/{tid}-{c}-{a}-{l}-{y}-{by}-P{p}.html",
            lambda p: f"{self.SITE}/show/{tid}-{a}-{by}-{c}-{l}----{p}---{y}.html",
            lambda p: f"{self.SITE}/vodshow/{tid}-{a}-{by}-{c}-{l}----{p}---{y}.html",
        ]
        
        # 如果完全沒有選擇篩選，提供乾淨的頻道格式備用
        if not any([cls, area, lang, year]) and by == "3":
            candidates.extend([
                lambda p: f"{self.SITE}/channel/{tid}-{p}.html",
                lambda p: f"{self.SITE}/channel/{tid}.html?page={p}",
            ])

        order = list(range(len(candidates)))
        cached = self.pattern_cache.get(mode)
        if cached is not None:
            order.remove(cached)
            order.insert(0, cached)

        result = []
        for idx in order:
            try:
                url = candidates[idx](pg)
                html = self._fetch(url)
                lst = self._parse_list(html)
            except Exception:
                continue
                
            if not lst:
                continue
                
            ids = set(m["vod_id"] for m in lst)
            
            if pg == 1:
                self.page1_ids[mode] = ids
                self.pattern_cache.setdefault(mode, idx)
            else:
                base = self.page1_ids.get(mode)
                if base is None:
                    try:
                        first_url = candidates[idx](1)
                        first_lst = self._parse_list(self._fetch(first_url))
                        base = set(m["vod_id"] for m in first_lst)
                        self.page1_ids[mode] = base
                    except Exception:
                        base = set()
                        
                # 如果第二頁拿到的影片跟第一頁完全相同，代表這組 URL 網站不認得，退回了第一頁
                if ids and ids.issubset(base):
                    continue
                    
                self.pattern_cache[mode] = idx
                
            result = lst
            break

        return {
            "list": result,
            "page": pg,
            "pagecount": pg + 1 if result else pg,
            "limit": 90,
            "total": 999999,
        }

    # ------------------------------------------------------------------
    # 詳情與多線路解析
    # ------------------------------------------------------------------
    def detailContent(self, ids):
        vid = ids[0] if ids else ""
        if not vid:
            return {"list": []}
        try:
            html = self._fetch(f"{self.SITE}/detail/{vid}.html")
        except Exception:
            return {"list": []}

        title = ""
        m = re.search(r"<title>(.+?)</title>", html, re.S)
        if m:
            title = m.group(1).split("-")[0].strip()
            title = re.sub(r"可可影视|可可影視|kekys\.com", "", title, flags=re.I)
            title = re.sub(r"\s+", " ", title).strip()

        pic = ""
        m = re.search(r'property=["\']og:image["\']\s+content=["\']([^"\']+)', html, re.I)
        if m:
            pic = self._fix_url(m.group(1))
        desc = ""
        m = re.search(r'name=["\']description["\']\s+content=["\']([^"\']*)', html, re.I)
        if m:
            desc = m.group(1).strip()

        eps_by_sid = {}
        sid_order = []
        seen = set()
        for a_tag, inner in re.findall(r'(<a\b[^>]*episode-item[^>]*>)(.*?)</a>', html, re.S):
            hm = re.search(r'href=["\']([^"\']+)["\']', a_tag)
            if not hm:
                continue
            href = hm.group(1)
            pm = re.search(r'/play/\d+-(\d+)-\d+\.html', href)
            if not pm or href in seen:
                continue
            name = re.sub(r"<[^>]+>", "", inner).strip()
            if not name:
                continue
            seen.add(href)
            sid = pm.group(1)
            if sid not in eps_by_sid:
                eps_by_sid[sid] = []
                sid_order.append(sid)
            eps_by_sid[sid].append(f"{name.replace('$', '').replace('#', '')}${href}")

        labels = [x.strip() for x in re.findall(
            r'class=["\'][^"\']*source-item-label[^"\']*["\'][^>]*>([^<]+)', html, re.I) if x.strip()]

        play_from, play_url = [], []
        for i, sid in enumerate(sid_order):
            line = labels[i] if i < len(labels) else f"線路{sid}"
            if line in self.SKIP_LINES:
                continue
            play_from.append(line.replace("$", ""))
            play_url.append("#".join(eps_by_sid[sid]))

        vod = {
            "vod_id": vid,
            "vod_name": title,
            "vod_pic": pic,
            "vod_content": desc,
            "vod_play_from": "$$$".join(play_from),
            "vod_play_url": "$$$".join(play_url),
        }
        return {"list": [vod]}

    def searchContent(self, key, quick, pg="1"):
        pg = int(pg or 1)
        k = quote(key)
        try:
            text = self._fetch(f"{self.SITE}/search?k={k}")
            m = re.search(r'name=["\']t["\']\s+value=["\']([^"\']+)', text)
            if m:
                url = f"{self.SITE}/search?k={k}&t={quote(m.group(1))}"
                if pg > 1:
                    url += f"&page={pg}"
                text = self._fetch(url)
        except Exception:
            return {"list": []}

        lst = []
        seen = set()
        for a_tag, inner in re.findall(r'(<a\b[^>]*search-result-item[^>]*>)(.*?)</a>', text, re.S):
            hm = re.search(r'href=["\']([^"\']+)["\']', a_tag)
            vm = re.search(r'/detail/(\d+)\.html', hm.group(1)) if hm else None
            if not vm or vm.group(1) in seen:
                continue
            tm = re.search(r'class=["\'][^"\']*title[^"\']*["\'][^>]*>(.*?)<', inner, re.S)
            name = tm.group(1).strip() if tm else ""
            if not name:
                am = re.search(r'(?:alt|title)=["\']([^"\']+)', inner)
                name = am.group(1).strip() if am else ""
            if not name:
                continue
            seen.add(vm.group(1))
            lst.append({
                "vod_id": vm.group(1),
                "vod_name": name,
                "vod_pic": self._pic_from_html(inner),
                "vod_remarks": "",
            })
        return {"list": lst, "page": pg, "pagecount": pg + 1 if lst else pg}

    def playerContent(self, flag, id, vipFlags):
        page_url = id if id.startswith("http") else self.SITE + id
        header = {"User-Agent": self.UA, "Referer": self.SITE + "/"}
        try:
            text = self._fetch(page_url)
        except Exception:
            return {"parse": 1, "jx": 0, "playUrl": "", "url": page_url, "header": header}

        v = None
        patterns = [
            r'src\s*:\s*["\']([^"\']+\.(?:m3u8|mp4)[^"\']*)["\']',
            r'["\']url["\']\s*:\s*["\']([^"\']+\.(?:m3u8|mp4)[^"\']*)["\']',
            r'url\s*:\s*["\']([^"\']+\.(?:m3u8|mp4)[^"\']*)["\']',
        ]
        for p in patterns:
            m = re.search(p, text, re.I | re.S)
            if m:
                v = m.group(1)
                break

        if not v:
            urls = re.findall(r'https?:\\?/\\?/[^\s"\'<>]+?\.(?:m3u8|mp4)[^\s"\'<>]*', text, re.I)
            if urls:
                urls = [u.replace("\\/", "/") for u in urls]
                for u in urls:
                    if "index.m3u8" in u or "video.m3u8" in u or ".mp4" in u:
                        v = u
                        break
                if not v:
                    v = urls[0]

        if v:
            v = v.replace("\\/", "/")
            return {"parse": 0, "jx": 0, "playUrl": "", "url": v, "header": header}
        return {"parse": 1, "jx": 0, "playUrl": "", "url": page_url, "header": header}

    def localProxy(self, param):
        return None

    def _fetch(self, url):
        r = self.session.get(url, timeout=15, verify=False)
        r.raise_for_status()
        if not r.encoding or r.encoding.lower() == "iso-8859-1":
            r.encoding = r.apparent_encoding or "utf-8"
        return r.text

    def _fix_url(self, src):
        if not src:
            return ""
        if src.startswith("//"):
            return "https:" + src
        if src.startswith("/"):
            return self.IMG_CDN + src
        return src

    def _pic_from_html(self, html):
        for tag in re.findall(r"<img\b[^>]*>", html, re.S):
            for attr in ("data-original", "data-src", "src"):
                m = re.search(attr + r'=["\']([^"\']+)["\']', tag)
                if m and "placeholder" not in m.group(1):
                    return self._fix_url(m.group(1))
        return ""

    def _parse_list(self, html):
        lst = []
        seen = set()
        if etree is not None:
            doc = etree.HTML(html)
            if doc is None:
                return lst
            for item in doc.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," module-item ")]'):
                a = item.xpath('.//a[contains(concat(" ",normalize-space(@class)," ")," v-item ")]')
                if not a:
                    continue
                href = a[0].get("href") or ""
                m = re.search(r"/detail/(\d+)\.html", href) or re.search(r"/play/(\d+)-", href)
                if not m or m.group(1) in seen:
                    continue
                title = ""
                for t in item.xpath('.//*[contains(@class,"v-item-title")]'):
                    s = "".join(t.itertext()).strip()
                    if s and s != self.SITE_TITLE:
                        title = s
                if not title:
                    continue
                pic = ""
                for img in item.xpath(".//img"):
                    src = img.get("data-original") or img.get("data-src") or img.get("src") or ""
                    if src and "placeholder" not in src:
                        pic = self._fix_url(src)
                        break
                rem = item.xpath('.//*[contains(@class,"v-item-bottom")]//span')
                remarks = "".join(rem[0].itertext()).strip() if rem else ""
                seen.add(m.group(1))
                lst.append({"vod_id": m.group(1), "vod_name": title,
                            "vod_pic": pic, "vod_remarks": remarks})
            return lst

        for block in re.split(r'(?=<[^>]+class=["\'][^"\']*module-item[^"\']*["\'])', html)[1:]:
            m = re.search(r"/detail/(\d+)\.html", block)
            if not m or m.group(1) in seen:
                continue
            titles = [re.sub(r"<[^>]+>", "", t).strip() for t in
                      re.findall(r'v-item-title[^>]*>(.*?)</', block, re.S)]
            titles = [t for t in titles if t and t != self.SITE_TITLE]
            if not titles:
                continue
            rm = re.search(r'v-item-bottom[^>]*>.*?<span[^>]*>(.*?)</span>', block, re.S)
            seen.add(m.group(1))
            lst.append({"vod_id": m.group(1), "vod_name": titles[-1],
                        "vod_pic": self._pic_from_html(block),
                        "vod_remarks": re.sub(r"<[^>]+>", "", rm.group(1)).strip() if rm else ""})
        return lst