# -*- coding: utf-8 -*-
"""
红牛影视聚合爬虫（XML 接口版 + 内置去广告清洗 + 敏感分类过滤）
- 单源：红牛 XML 接口
- 解析 XML 格式的分类、列表、详情与搜索数据
- 播放 M3U8 时通过本地代理清洗广告
- 按 /adjump/ 路径删除广告片段
- 自动过滤伦理、福利、擦边等敏感类目及对应影片
"""

import sys
import concurrent.futures
import re
import requests
import time
import xml.etree.ElementTree as ET
from urllib.parse import urljoin, urlparse, quote, parse_qs, urlencode, urlunparse
from collections import OrderedDict

sys.path.append("..")

from base.spider import Spider


class Spider(Spider):
    SOURCES = {
        "红牛": {
            "name": "红牛",
            "api": "https://www.hongniuzy3.com/api.php/provide/vod/from/hnm3u8/at/xml/",
        }
    }

    # 屏蔽/过滤关键词列表
    BLOCKED_CATEGORIES = (
        "伦理",
        "福利",
        "伦理片",
        "倫理片",
        "港台三级",
        "里番动漫",
        "里番",
        "韩国伦理",
        "两性课堂",
        "写真热舞",
        "擦边剧",
        "擦边短剧",
        "西方伦理",
        "日本伦理",
    )

    AD_KEYWORD = "/adjump/"
    TIMEOUT = 12
    MAX_RETRIES = 2
    MAX_CACHE_SIZE = 20  # 缓存容量

    def init(self, extend=""):
        self.session = requests.Session()
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/131.0.0.0 Safari/537.36"
            )
        }
        self.cache = OrderedDict()

    # ==================== 黑名单过滤 ====================

    def _is_blocked(self, type_name):
        """检查分类名称是否命中过滤词库"""
        if not type_name:
            return False
        name = str(type_name).strip()
        for word in self.BLOCKED_CATEGORIES:
            if word in name:
                return True
        return False

    # ==================== 缓存管理 ====================

    def _get_cache(self, url):
        if url in self.cache:
            self.cache.move_to_end(url)
            return self.cache[url]
        return None

    def _set_cache(self, url, content):
        self.cache[url] = content
        self.cache.move_to_end(url)
        if len(self.cache) > self.MAX_CACHE_SIZE:
            self.cache.popitem(last=False)

    # ==================== M3U8 清洗 ====================

    def _fetch_m3u8(self, url):
        for attempt in range(1, self.MAX_RETRIES + 1):
            try:
                resp = self.session.get(url, headers=self.headers, timeout=self.TIMEOUT)
                if resp.status_code == 200 and resp.text:
                    return resp.text
            except Exception:
                if attempt < self.MAX_RETRIES:
                    time.sleep(0.5)
        return None

    def _parse_segments(self, lines):
        segments = []
        current = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if line == "#EXT-X-DISCONTINUITY":
                if current:
                    segments.append(current)
                    current = []
            else:
                current.append(line)
        if current:
            segments.append(current)
        return segments

    def _segment_has_ad(self, segment):
        for line in segment:
            if not line.startswith("#") and self.AD_KEYWORD in line.lower():
                return True
        return False

    def _rewrite_urls_in_segment(self, segment, base_url):
        new_segment = []
        i = 0
        while i < len(segment):
            line = segment[i]
            if line.startswith("#EXT-X-KEY:") and "URI=" in line:
                match = re.search(r'URI="([^"]+)"', line)
                if match:
                    old_uri = match.group(1)
                    if not old_uri.startswith(("http://", "https://")):
                        new_uri = urljoin(base_url, old_uri)
                        line = line.replace(f'URI="{old_uri}"', f'URI="{new_uri}"')
                new_segment.append(line)
                i += 1
                continue

            if line.startswith("#EXTINF:"):
                new_segment.append(line)
                if i + 1 < len(segment):
                    ts_path = segment[i + 1].strip()
                    if not ts_path.startswith(("http://", "https://")):
                        ts_path = urljoin(base_url, ts_path)
                    new_segment.append(ts_path)
                    i += 2
                    continue

            new_segment.append(line)
            i += 1
        return new_segment

    def _clean_m3u8_content(self, content, base_url, debug=False):
        lines = content.splitlines()
        header, body_lines, footer = [], [], []
        in_body = False

        for line in lines:
            sline = line.strip()
            if not sline:
                continue
            if sline == "#EXT-X-ENDLIST":
                footer.append(sline)
                break

            if not in_body:
                if sline.startswith("#EXTM3U") or sline.startswith("#EXT-X-"):
                    if sline.startswith("#EXT-X-KEY:") and "URI=" in sline:
                        match = re.search(r'URI="([^"]+)"', sline)
                        if match:
                            old_uri = match.group(1)
                            if not old_uri.startswith(("http://", "https://")):
                                new_uri = urljoin(base_url, old_uri)
                                sline = sline.replace(f'URI="{old_uri}"', f'URI="{new_uri}"')
                    header.append(sline)
                else:
                    in_body = True
                    body_lines.append(sline)
            else:
                body_lines.append(sline)

        segments = self._parse_segments(body_lines)
        cleaned, ad_count = [], 0

        for segment in segments:
            if self._segment_has_ad(segment):
                ad_count += 1
                continue
            cleaned.append(self._rewrite_urls_in_segment(segment, base_url))

        result = list(header)
        for segment in cleaned:
            result.extend(segment)
        result.extend(footer)

        return "\n".join(result)

    def _pick_variant(self, content, base_url):
        lines = [line.strip() for line in content.splitlines() if line.strip()]
        best_url, best_bandwidth = None, -1

        for i, line in enumerate(lines):
            if line.startswith("#EXT-X-STREAM-INF"):
                match = re.search(r"BANDWIDTH=(\d+)", line)
                bandwidth = int(match.group(1)) if match else 0

                for j in range(i + 1, len(lines)):
                    if not lines[j].startswith("#"):
                        variant_url = urljoin(base_url, lines[j])
                        if bandwidth >= best_bandwidth:
                            best_url = variant_url
                            best_bandwidth = bandwidth
                        break
        return best_url

    # ==================== XML 解析与网络请求 ====================

    def _normalize_url(self, url):
        parsed = urlparse(url)
        query_params = parse_qs(parsed.query)
        for param in ("_", "t", "timestamp", "rand", "v", "cb", "callback"):
            query_params.pop(param, None)
        return urlunparse(parsed._replace(query=urlencode(query_params, doseq=True)))

    def build_url(self, base, query):
        if "?" in base:
            return base if base.endswith(("?", "&")) else base + "&" + query
        return base + "?" + query

    def fetch_xml(self, url, timeout=10):
        """请求 XML 数据并解析为 ElementTree"""
        try:
            resp = self.session.get(url, headers=self.headers, timeout=timeout)
            if resp.status_code == 200 and resp.text:
                return ET.fromstring(resp.content)
        except Exception:
            pass
        return None

    def _parse_xml_list(self, root):
        """将 XML 中的 <video> 或 <item> 列表节点解析成 dict 字典列表"""
        if root is None:
            return []

        items = []
        list_node = root.find(".//list")
        if list_node is None:
            return items

        video_nodes = list_node.findall("video")
        if not video_nodes:
            video_nodes = list_node.findall("item")

        for video in video_nodes:
            item = {}
            for child in video:
                tag = child.tag.split("}", 1)[-1].lower()
                if tag == "dl":
                    play_from = []
                    play_url = []
                    for dd in child.findall("dd"):
                        flag = dd.attrib.get("flag", "hnm3u8")
                        text = dd.text or ""
                        play_from.append(flag)
                        play_url.append(text)
                    item["vod_play_from"] = "$$$".join(play_from)
                    item["vod_play_url"] = "$$$".join(play_url)
                elif tag == "id":
                    item["vod_id"] = child.text or ""
                elif tag == "name":
                    item["vod_name"] = child.text or ""
                elif tag == "type":
                    item["type_name"] = child.text or ""
                elif tag == "pic":
                    item["vod_pic"] = child.text or ""
                elif tag == "note":
                    item["vod_remarks"] = child.text or ""
                elif tag == "des":
                    item["vod_content"] = child.text or ""
                elif tag == "last":
                    item["vod_time"] = child.text or ""
                elif tag == "dt":
                    if not item.get("vod_play_from"):
                        item["vod_play_from"] = child.text or ""
                else:
                    item[f"vod_{tag}"] = child.text or ""

            if item:
                items.append(item)
        return items

    def _parse_xml_page_info(self, root):
        """解析 XML 头部翻页信息"""
        if root is None:
            return {"page": 1, "pagecount": 0, "limit": 20, "total": 0}

        list_node = root.find(".//list")
        if list_node is not None:
            return {
                "page": int(list_node.attrib.get("page", 1)),
                "pagecount": int(list_node.attrib.get("pagecount", 0)),
                "limit": int(list_node.attrib.get("pagesize", 20)),
                "total": int(list_node.attrib.get("recordcount", 0)),
            }
        return {"page": 1, "pagecount": 0, "limit": 20, "total": 0}

    # ==================== 分类解析 ====================

    def _safe_int(self, value, default=0):
        try:
            return int(str(value).strip())
        except Exception:
            return default

    def _parse_xml_classes(self, root):
        """解析 XML 分类列表，并过滤敏感分类"""
        result = []
        if root is None:
            return result

        class_node = root.find(".//class")
        if class_node is None:
            return result

        seen = set()

        for node in list(class_node):
            if node.tag.lower() not in ("ty", "type", "class"):
                continue

            type_id = (
                node.attrib.get("id")
                or node.attrib.get("type_id")
                or node.attrib.get("value")
                or ""
            ).strip()

            type_name = (
                node.attrib.get("name")
                or node.attrib.get("type_name")
                or (node.text or "")
            ).strip()

            if not type_id:
                for child in node:
                    if child.tag.lower() in ("id", "type_id"):
                        type_id = (child.text or "").strip()
                    elif child.tag.lower() in ("name", "type_name"):
                        type_name = (child.text or "").strip()

            if not type_id or not type_name:
                continue

            # 过滤敏感分类
            if self._is_blocked(type_name):
                continue

            key = (type_id, type_name)
            if key in seen:
                continue

            seen.add(key)
            result.append({
                "type_id": type_id,
                "type_name": type_name,
            })

        return result

    def _get_source_classes(self, source_key, source_info):
        """读取单个资源站的 XML 分类并缓存"""
        cache_key = "__classes__:" + source_key
        cached = self._get_cache(cache_key)
        if cached is not None:
            return cached

        url = self.build_url(source_info["api"], "ac=list")
        root = self.fetch_xml(url, timeout=8)
        classes = self._parse_xml_classes(root)

        self._set_cache(cache_key, classes)
        return classes

    # ==================== 视频数据接口 ====================

    def clean_item(self, item, source_key, source_name, is_detail=False):
        if not is_detail:
            item["vod_id"] = f"{source_key}@@{item.get('vod_id', '')}"

        old_remark = item.get("vod_remarks", "")
        item["vod_remarks"] = f"{source_name} | {old_remark}" if old_remark else source_name
        return item

    def homeContent(self, filter=False):
        classes = []
        filters = {}

        def fetch_classes(source_key, source_info):
            return (
                source_key,
                source_info,
                self._get_source_classes(source_key, source_info),
            )

        with concurrent.futures.ThreadPoolExecutor(
            max_workers=max(1, min(5, len(self.SOURCES)))
        ) as executor:
            futures = [
                executor.submit(fetch_classes, source_key, source_info)
                for source_key, source_info in self.SOURCES.items()
            ]

            for future in concurrent.futures.as_completed(futures):
                try:
                    source_key, source_info, source_classes = future.result()
                except Exception:
                    continue

                all_type_id = f"{source_key}@@"
                classes.append({
                    "type_id": all_type_id,
                    "type_name": f"{source_info['name']}-全部",
                })

                for item in source_classes:
                    real_type_id = item["type_id"]
                    type_name = item["type_name"]

                    classes.append({
                        "type_id": f"{source_key}@@{real_type_id}",
                        "type_name": f"{source_info['name']}-{type_name}",
                    })

                filter_values = [
                    {
                        "n": "全部(最新)",
                        "v": "",
                    }
                ]

                for item in source_classes:
                    filter_values.append({
                        "n": item["type_name"],
                        "v": item["type_id"],
                    })

                filters[source_key] = [{
                    "key": "cateId",
                    "name": "分类",
                    "value": filter_values,
                }]

        unique_classes = []
        seen = set()

        for item in classes:
            key = item.get("type_id", "")
            if not key or key in seen:
                continue
            seen.add(key)
            unique_classes.append(item)

        return {
            "class": unique_classes,
            "filters": filters,
            "list": [],
        }

    def homeVideoContent(self):
        return {"list": []}

    def categoryContent(self, tid, pg=1, filter=False, extend=None):
        extend = extend or {}

        if not tid:
            return {
                "list": [],
                "page": pg,
                "pagecount": 0,
                "limit": 20,
                "total": 0,
            }

        if "@@" in str(tid):
            source_key, real_tid = str(tid).split("@@", 1)
        else:
            source_key = str(tid)
            real_tid = ""

        if source_key not in self.SOURCES:
            return {
                "list": [],
                "page": pg,
                "pagecount": 0,
                "limit": 20,
                "total": 0,
            }

        source = self.SOURCES[source_key]

        if extend.get("cateId") is not None:
            real_tid = str(extend.get("cateId") or "").strip()

        try:
            page = max(1, int(pg))
        except Exception:
            page = 1

        query_parts = [
            "ac=videolist",
            f"pg={page}",
        ]

        if real_tid:
            query_parts.append(f"t={quote(real_tid, safe='')}")

        url = self.build_url(
            source["api"],
            "&".join(query_parts),
        )

        root = self.fetch_xml(url, timeout=self.TIMEOUT)

        if root is None:
            return {
                "list": [],
                "page": page,
                "pagecount": 0,
                "limit": 20,
                "total": 0,
            }

        items = self._parse_xml_list(root)
        page_info = self._parse_xml_page_info(root)

        video_list = []
        seen = set()

        for item in items:
            # 过滤敏感分类对应的影片
            type_name = item.get("type_name", "")
            if self._is_blocked(type_name):
                continue

            real_id = str(item.get("vod_id", "")).strip()
            if not real_id:
                continue

            cleaned = self.clean_item(
                item,
                source_key,
                source["name"],
                is_detail=False,
            )

            if cleaned.get("vod_id") in seen:
                continue

            seen.add(cleaned.get("vod_id"))
            video_list.append(cleaned)

        return {
            "list": video_list,
            "page": page_info["page"] or page,
            "pagecount": page_info["pagecount"],
            "limit": page_info["limit"],
            "total": page_info["total"],
        }

    def detailContent(self, ids):
        if not ids or "@@" not in ids[0]:
            return {"list": []}

        full_id = ids[0]
        source_key, real_id = full_id.split("@@", 1)

        if source_key not in self.SOURCES:
            return {"list": []}

        source = self.SOURCES[source_key]
        url = self.build_url(source["api"], f"ac=videolist&ids={quote(str(real_id))}")
        root = self.fetch_xml(url, timeout=10)

        if root is None:
            return {"list": []}

        items = self._parse_xml_list(root)
        result_list = []
        for item in items:
            # 详情页同样核验敏感分类
            type_name = item.get("type_name", "")
            if self._is_blocked(type_name):
                continue

            cleaned = self.clean_item(item, source_key, source["name"], is_detail=True)
            cleaned["vod_id"] = full_id
            result_list.append(cleaned)

        return {"list": result_list}

    def searchContent(self, key, quick=False, pg=1):
        keyword = key.strip()
        if not keyword:
            return {"list": [], "page": pg, "pagecount": 0, "limit": 40, "total": 0}

        encoded_keyword = quote(keyword)

        def search_source(source_key, source_info):
            url = self.build_url(source_info["api"], f"ac=videolist&wd={encoded_keyword}&pg={pg}")
            root = self.fetch_xml(url, timeout=8)
            if root is None:
                return source_key, source_info, None, []

            items = self._parse_xml_list(root)
            page_info = self._parse_xml_page_info(root)
            return source_key, source_info, page_info, items

        all_items, max_pagecount = [], 0

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = {
                executor.submit(search_source, s_key, val): s_key
                for s_key, val in self.SOURCES.items()
            }
            for future in concurrent.futures.as_completed(futures):
                source_key, source_info, page_info, items = future.result()
                if items:
                    for item in items:
                        # 搜索结果过滤敏感分类
                        type_name = item.get("type_name", "")
                        if self._is_blocked(type_name):
                            continue

                        cleaned = self.clean_item(item, source_key, source_info["name"], is_detail=False)
                        all_items.append(cleaned)
                    if page_info:
                        max_pagecount = max(max_pagecount, page_info.get("pagecount", 0))

        seen = set()
        unique = []
        for item in all_items:
            vod_id = item.get("vod_id")
            if vod_id not in seen:
                seen.add(vod_id)
                unique.append(item)

        return {
            "list": unique,
            "page": pg,
            "pagecount": max_pagecount or 1,
            "limit": 40,
            "total": len(unique),
        }

    # ==================== 播放与代理 ====================

    def playerContent(self, flag, id, vipFlags=None):
        raw_url = id
        if not raw_url:
            return {"parse": 0, "url": ""}

        if ".m3u8" in raw_url.lower():
            try:
                base_proxy = self.getProxyUrl(local=True)
            except TypeError:
                base_proxy = self.getProxyUrl()

            proxy_url = (
                base_proxy
                + "&action=clean&src="
                + quote(raw_url, safe="")
            )
            return {"parse": 0, "url": proxy_url}

        return {"parse": 0, "url": raw_url}

    def localProxy(self, param):
        if param.get("action") != "clean":
            return []

        src_url = param.get("src")
        if not src_url:
            return [400, "text/plain; charset=utf-8", "缺少 src 参数"]

        norm_url = self._normalize_url(src_url)

        cached_content = self._get_cache(norm_url)
        if cached_content is not None:
            return [
                200,
                "application/vnd.apple.mpegurl",
                cached_content,
                {
                    "Access-Control-Allow-Origin": "*",
                    "Cache-Control": "no-cache, no-store",
                },
            ]

        try:
            content = self._fetch_m3u8(src_url)
            if not content:
                return [500, "text/plain; charset=utf-8", "获取 m3u8 失败"]

            base_url = src_url.rsplit("/", 1)[0] + "/"
            hops = 0

            while "#EXT-X-STREAM-INF" in content and hops < 3:
                variant = self._pick_variant(content, base_url)
                if not variant:
                    break

                sub_content = self._fetch_m3u8(variant)
                if not sub_content:
                    break

                content = sub_content
                base_url = variant.rsplit("/", 1)[0] + "/"
                hops += 1

            cleaned = self._clean_m3u8_content(content, base_url, debug=False)
            self._set_cache(norm_url, cleaned)

            return [
                200,
                "application/vnd.apple.mpegurl",
                cleaned,
                {
                    "Access-Control-Allow-Origin": "*",
                    "Cache-Control": "no-cache, no-store",
                },
            ]

        except Exception as e:
            return [500, "text/plain; charset=utf-8", f"清洗失败: {e}"]

    def isVideoFormat(self, url):
        return False

    def manualVideoCheck(self):
        pass

    def destroy(self):
        try:
            self.session.close()
        except Exception:
            pass