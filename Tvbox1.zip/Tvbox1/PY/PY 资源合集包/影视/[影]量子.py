# -*- coding: utf-8 -*-
"""
量子影视聚合爬虫（内置去广告清洗）
- 单源：量子
- 播放 M3U8 时通过本地代理清洗广告
- 按 /adjump/ 路径删除广告片段
- 自动处理多码率 M3U8，选择最高带宽
- LRU 缓存机制提高并发/多播放兼容性
"""

import sys
import concurrent.futures
import re
import requests
import time
from urllib.parse import urljoin, urlparse, quote, parse_qs, urlencode, urlunparse
from collections import OrderedDict

sys.path.append("..")

from base.spider import Spider


class Spider(Spider):
    SOURCES = {
        "量子": {
            "name": "量子",
            "api": "https://cj.lziapi.com/api.php/provide/vod/?ac=list",
        }
    }

    AD_KEYWORD = "/adjump/"
    TIMEOUT = 12
    MAX_RETRIES = 2
    MAX_CACHE_SIZE = 20  # 缓存容量

    def init(self, extend=""):
        self.session = requests.Session()
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/131.0.0.0 Safari/537.36"
            )
        }
        # 使用 OrderedDict 实现简易 LRU 缓存
        self.cache = OrderedDict()

    # ==================== 缓存管理 ====================

    def _get_cache(self, url):
        if url in self.cache:
            self.cache.move_to_end(url)
            return self.cache[url]
        return None

    def _set_cache(self, url, content):
        self.cache[url] = content
        self.cache.move_to_end(url)
        if len(self.cache) > self.MAX_CACHE_SIZE:
            self.cache.popitem(last=False)

    # ==================== M3U8 清洗 ====================

    def _fetch_m3u8(self, url):
        """抓取 M3U8，失败后自动重试。"""
        for attempt in range(1, self.MAX_RETRIES + 1):
            try:
                resp = self.session.get(url, headers=self.headers, timeout=self.TIMEOUT)
                if resp.status_code == 200 and resp.text:
                    return resp.text
            except Exception:
                if attempt < self.MAX_RETRIES:
                    time.sleep(0.5)
        return None

    def _parse_segments(self, lines):
        """按 EXT-X-DISCONTINUITY 划分片段。"""
        segments = []
        current = []

        for line in lines:
            line = line.strip()
            if not line:
                continue

            if line == "#EXT-X-DISCONTINUITY":
                if current:
                    segments.append(current)
                    current = []
            else:
                current.append(line)

        if current:
            segments.append(current)

        return segments

    def _segment_has_ad(self, segment):
        """判断片段中是否包含广告关键词 TS。"""
        for line in segment:
            if not line.startswith("#") and self.AD_KEYWORD in line.lower():
                return True
        return False

    def _rewrite_urls_in_segment(self, segment, base_url):
        """把片段中的相对 URL 转换为绝对 URL。"""
        new_segment = []
        i = 0

        while i < len(segment):
            line = segment[i]

            # 处理加密 KEY
            if line.startswith("#EXT-X-KEY:") and "URI=" in line:
                match = re.search(r'URI="([^"]+)"', line)
                if match:
                    old_uri = match.group(1)
                    if not old_uri.startswith(("http://", "https://")):
                        new_uri = urljoin(base_url, old_uri)
                        line = line.replace(f'URI="{old_uri}"', f'URI="{new_uri}"')
                new_segment.append(line)
                i += 1
                continue

            # EXTINF 后面通常紧跟 TS 地址
            if line.startswith("#EXTINF:"):
                new_segment.append(line)
                if i + 1 < len(segment):
                    ts_path = segment[i + 1].strip()
                    if not ts_path.startswith(("http://", "https://")):
                        ts_path = urljoin(base_url, ts_path)
                    new_segment.append(ts_path)
                    i += 2
                    continue

            new_segment.append(line)
            i += 1

        return new_segment

    def _clean_m3u8_content(self, content, base_url, debug=False):
        """清除包含 /adjump/ 的广告片段。"""
        lines = content.splitlines()

        header, body_lines, footer = [], [], []
        in_body = False

        for line in lines:
            sline = line.strip()
            if not sline:
                continue

            if sline == "#EXT-X-ENDLIST":
                footer.append(sline)
                break

            if not in_body:
                if sline.startswith("#EXTM3U") or sline.startswith("#EXT-X-"):
                    # 修复 Key URI 相对路径
                    if sline.startswith("#EXT-X-KEY:") and "URI=" in sline:
                        match = re.search(r'URI="([^"]+)"', sline)
                        if match:
                            old_uri = match.group(1)
                            if not old_uri.startswith(("http://", "https://")):
                                new_uri = urljoin(base_url, old_uri)
                                sline = sline.replace(f'URI="{old_uri}"', f'URI="{new_uri}"')
                    header.append(sline)
                else:
                    in_body = True
                    body_lines.append(sline)
            else:
                body_lines.append(sline)

        segments = self._parse_segments(body_lines)
        cleaned, ad_count = [], 0

        for segment in segments:
            if self._segment_has_ad(segment):
                ad_count += 1
                continue
            cleaned.append(self._rewrite_urls_in_segment(segment, base_url))

        result = list(header)
        for segment in cleaned:
            result.extend(segment)
        result.extend(footer)

        if debug:
            debug_info = [
                f"# 保留段数: {len(cleaned)}, 滤除广告段数: {ad_count}",
                f"# 过滤规则: {self.AD_KEYWORD}",
                "# ========================",
            ]
            result = debug_info + result

        return "\n".join(result)

    def _pick_variant(self, content, base_url):
        """从多码率 M3U8 中选择最高 BANDWIDTH 的播放列表。"""
        lines = [line.strip() for line in content.splitlines() if line.strip()]
        best_url, best_bandwidth = None, -1

        for i, line in enumerate(lines):
            if line.startswith("#EXT-X-STREAM-INF"):
                match = re.search(r"BANDWIDTH=(\d+)", line)
                bandwidth = int(match.group(1)) if match else 0

                for j in range(i + 1, len(lines)):
                    if not lines[j].startswith("#"):
                        variant_url = urljoin(base_url, lines[j])
                        if bandwidth >= best_bandwidth:
                            best_url = variant_url
                            best_bandwidth = bandwidth
                        break

        return best_url

    # ==================== URL 处理与网络接口 ====================

    def _normalize_url(self, url):
        """删除常见随机/时间戳参数，提高缓存命中率。"""
        parsed = urlparse(url)
        query_params = parse_qs(parsed.query)

        for param in ("_", "t", "timestamp", "rand", "v", "cb", "callback"):
            query_params.pop(param, None)

        return urlunparse(parsed._replace(query=urlencode(query_params, doseq=True)))

    def build_url(self, base, query):
        if "?" in base:
            return base if base.endswith(("?", "&")) else base + "&" + query
        return base + "?" + query

    def fetch_json(self, url, timeout=10):
        try:
            resp = self.session.get(url, headers=self.headers, timeout=timeout)
            if resp.status_code == 200:
                return resp.json()
        except Exception:
            pass
        return None

    # ==================== 视频数据接口 ====================

    def clean_item(self, item, source_key, source_name, is_detail=False):
        if not is_detail:
            item["vod_id"] = f"{source_key}@@{item.get('vod_id', '')}"

        old_remark = item.get("vod_remarks", "")
        item["vod_remarks"] = f"{source_name} | {old_remark}" if old_remark else source_name
        item.pop("vod_down_from", None)
        item.pop("vod_down_url", None)
        return item

    def homeContent(self, filter=False):
        classes, filters = [], {}

        def fetch_class(source_key, source_info):
            url = self.build_url(source_info["api"], "ac=list")
            data = self.fetch_json(url, timeout=4)
            return source_key, source_info, data

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = {
                executor.submit(fetch_class, s_key, val): s_key
                for s_key, val in self.SOURCES.items()
            }
            for future in concurrent.futures.as_completed(futures):
                source_key, source_info, data = future.result()
                classes.append({"type_id": source_key, "type_name": source_info["name"]})

                filter_values = [{"n": "全部(最新)", "v": ""}]
                if data and "class" in data:
                    for category in data["class"]:
                        filter_values.append({"n": category["type_name"], "v": category["type_id"]})

                filters[source_key] = [{"key": "cateId", "name": "分类", "value": filter_values}]

        return {"class": classes, "filters": filters, "list": []}

    def homeVideoContent(self):
        return {"list": []}

    def categoryContent(self, tid, pg=1, filter=False, extend=None):
        if tid not in self.SOURCES:
            return {"list": [], "page": pg, "pagecount": 0, "limit": 20, "total": 0}

        source = self.SOURCES[tid]
        extend = extend or {}
        real_tid = extend.get("cateId", "")

        query = f"ac=detail&pg={pg}"
        if real_tid:
            query += f"&t={quote(str(real_tid))}"

        url = self.build_url(source["api"], query)
        data = self.fetch_json(url, timeout=10)

        if not data:
            return {"list": [], "page": pg, "pagecount": 0, "limit": 20, "total": 0}

        video_list = [
            self.clean_item(item, tid, source["name"], is_detail=False)
            for item in data.get("list", [])
        ]

        return {
            "list": video_list,
            "page": data.get("page", pg),
            "pagecount": data.get("pagecount", 0),
            "limit": data.get("limit", 20),
            "total": data.get("total", 0),
        }

    def detailContent(self, ids):
        if not ids or "@@" not in ids[0]:
            return {"list": []}

        full_id = ids[0]
        source_key, real_id = full_id.split("@@", 1)

        if source_key not in self.SOURCES:
            return {"list": []}

        source = self.SOURCES[source_key]
        url = self.build_url(source["api"], f"ac=detail&ids={quote(str(real_id))}")
        data = self.fetch_json(url, timeout=10)

        if not data or "list" not in data:
            return {"list": []}

        result_list = []
        for item in data["list"]:
            cleaned = self.clean_item(item, source_key, source["name"], is_detail=True)
            cleaned["vod_id"] = full_id
            result_list.append(cleaned)

        return {"list": result_list}

    def searchContent(self, key, quick=False, pg=1):
        keyword = key.strip()
        if not keyword:
            return {"list": [], "page": pg, "pagecount": 0, "limit": 40, "total": 0}

        encoded_keyword = quote(keyword)

        def search_source(source_key, source_info):
            test_urls = [
                self.build_url(source_info["api"], f"ac=detail&wd={encoded_keyword}&pg={pg}"),
                self.build_url(source_info["api"], f"ac=list&wd={encoded_keyword}&pg={pg}"),
            ]
            for url in test_urls:
                data = self.fetch_json(url, timeout=8)
                if not data:
                    continue

                items = None
                if isinstance(data, dict):
                    if "list" in data:
                        items = data["list"]
                    elif "data" in data and isinstance(data["data"], dict):
                        items = data["data"].get("list")
                    elif "data" in data and isinstance(data["data"], list):
                        items = data["data"]

                if items:
                    return source_key, source_info, data, items

            return source_key, source_info, None, []

        all_items, max_pagecount = [], 0

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = {
                executor.submit(search_source, s_key, val): s_key
                for s_key, val in self.SOURCES.items()
            }
            for future in concurrent.futures.as_completed(futures):
                source_key, source_info, data, items = future.result()
                if items:
                    for item in items:
                        cleaned = self.clean_item(item, source_key, source_info["name"], is_detail=False)
                        all_items.append(cleaned)
                    if data:
                        max_pagecount = max(max_pagecount, data.get("pagecount", 0))

        seen = set()
        unique = []
        for item in all_items:
            vod_id = item.get("vod_id")
            if vod_id not in seen:
                seen.add(vod_id)
                unique.append(item)

        return {
            "list": unique,
            "page": pg,
            "pagecount": max_pagecount or 1,
            "limit": 40,
            "total": len(unique),
        }

    # ==================== 播放与代理 ====================

    def playerContent(self, flag, id, vipFlags=None):
        raw_url = id
        if not raw_url:
            return {"parse": 0, "url": ""}

        if ".m3u8" in raw_url.lower():
            # 使用 try-except 兼容不同版本的 BaseSpider.getProxyUrl()
            try:
                base_proxy = self.getProxyUrl(local=True)
            except TypeError:
                base_proxy = self.getProxyUrl()

            proxy_url = (
                base_proxy
                + "&action=clean&src="
                + quote(raw_url, safe="")
            )
            return {"parse": 0, "url": proxy_url}

        return {"parse": 0, "url": raw_url}

    def localProxy(self, param):
        if param.get("action") != "clean":
            return []

        src_url = param.get("src")
        if not src_url:
            return [400, "text/plain; charset=utf-8", "缺少 src 参数"]

        norm_url = self._normalize_url(src_url)

        # 命中 LRU 缓存
        cached_content = self._get_cache(norm_url)
        if cached_content is not None:
            return [
                200,
                "application/vnd.apple.mpegurl",
                cached_content,
                {
                    "Access-Control-Allow-Origin": "*",
                    "Cache-Control": "no-cache, no-store",
                },
            ]

        try:
            content = self._fetch_m3u8(src_url)
            if not content:
                return [500, "text/plain; charset=utf-8", "获取 m3u8 失败"]

            base_url = src_url.rsplit("/", 1)[0] + "/"
            hops = 0

            # 跟随多码率，最高 3 层
            while "#EXT-X-STREAM-INF" in content and hops < 3:
                variant = self._pick_variant(content, base_url)
                if not variant:
                    break

                sub_content = self._fetch_m3u8(variant)
                if not sub_content:
                    break

                content = sub_content
                base_url = variant.rsplit("/", 1)[0] + "/"
                hops += 1

            cleaned = self._clean_m3u8_content(content, base_url, debug=False)

            # 写入 LRU 缓存
            self._set_cache(norm_url, cleaned)

            return [
                200,
                "application/vnd.apple.mpegurl",
                cleaned,
                {
                    "Access-Control-Allow-Origin": "*",
                    "Cache-Control": "no-cache, no-store",
                },
            ]

        except Exception as e:
            return [500, "text/plain; charset=utf-8", f"清洗失败: {e}"]

    def isVideoFormat(self, url):
        return False

    def manualVideoCheck(self):
        pass

    def destroy(self):
        try:
            self.session.close()
        except Exception:
            pass